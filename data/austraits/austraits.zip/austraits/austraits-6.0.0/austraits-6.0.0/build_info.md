$version
[1] "6.0.0"

$git_SHA
[1] "feabdc40196ebf0f93f9f6d019e5c59715152884"

$session_info
R version 4.4.0 (2024-04-24)
Platform: aarch64-apple-darwin20
Running under: macOS Sonoma 14.4.1

Matrix products: default
BLAS:   /System/Library/Frameworks/Accelerate.framework/Versions/A/Frameworks/vecLib.framework/Versions/A/libBLAS.dylib 
LAPACK: /Library/Frameworks/R.framework/Versions/4.4-arm64/Resources/lib/libRlapack.dylib;  LAPACK version 3.12.0

locale:
[1] en_US.UTF-8/en_US.UTF-8/en_US.UTF-8/C/en_US.UTF-8/en_US.UTF-8

time zone: Australia/Sydney
tzcode source: internal

attached base packages:
[1] stats     graphics  grDevices datasets  utils     methods   base     

other attached packages:
 [1] traits.build_1.1.0.9000 tidyr_1.3.1             stringr_1.5.1           readr_2.1.5            
 [5] lubridate_1.9.3         dplyr_1.1.4             devtools_2.4.5          usethis_2.2.3          
 [9] datapasta_3.1.0         rdoc_0.1.0.9000        

loaded via a namespace (and not attached):
 [1] htmlwidgets_1.6.4 remotes_2.5.0     tzdb_0.4.0        vctrs_0.6.5       tools_4.4.0       generics_0.1.3   
 [7] parallel_4.4.0    tibble_3.2.1      fansi_1.0.6       RefManageR_1.4.0  pacman_0.5.1      pkgconfig_2.0.3  
[13] R.oo_1.26.0       lifecycle_1.0.4   R.cache_0.16.0    compiler_4.4.0    brio_1.1.5        httpuv_1.6.15    
[19] htmltools_0.5.8.1 yaml_2.3.8        later_1.3.2       pillar_1.9.0      crayon_1.5.2      urlchecker_1.0.1 
[25] ellipsis_0.3.2    R.utils_2.12.3    cachem_1.0.8      sessioninfo_1.2.2 mime_0.12         styler_1.10.3    
[31] tidyselect_1.2.1  digest_0.6.35     stringi_1.8.4     purrr_1.0.2       bibtex_0.5.1      fastmap_1.1.1    
[37] cli_3.6.2         magrittr_2.0.3    pkgbuild_1.4.4    utf8_1.2.4        withr_3.0.0       promises_1.3.0   
[43] backports_1.4.1   bit64_4.0.5       timechange_0.3.0  httr_1.4.7        bit_4.0.5         R.methodsS3_1.8.2
[49] hms_1.1.3         memoise_2.0.1     shiny_1.8.1.1     testthat_3.2.1.1  miniUI_0.1.1.1    profvis_0.3.8    
[55] rlang_1.1.3       Rcpp_1.0.12       xtable_1.8-4      glue_1.7.0        xml2_1.3.6        pkgload_1.3.4    
[61] vroom_1.6.5       jsonlite_1.8.8    R6_2.5.1          plyr_1.8.9        fs_1.6.4         

